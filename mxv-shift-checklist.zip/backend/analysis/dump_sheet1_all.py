import openpyxl
import sys

sys.stdout.reconfigure(encoding='utf-8')

wb = openpyxl.load_workbook(r"C:\Users\hiepth\OneDrive - MERCANTILE EXCHANGE OF VIETNAM\Documents\Github\mxv-shift-checklist\marco\Thong ke so lot giao dich có ACM\Macro thong ke so lot giao dich có ACM.xlsm", read_only=True)
sheet1 = wb["Sheet1"]
sheet2 = wb["Sheet2"]

print("--- SHEET1 SINGLE CELLS ---")
for cell_name in ["N3", "AD11", "BM8", "AF4"]:
    cell = sheet1[cell_name]
    print(f"Sheet1!{cell_name}: value={cell.value}")

print("\n--- SHEET2 SINGLE CELLS ---")
for cell_name in ["AF3", "AF4"]:
    cell = sheet2[cell_name]
    print(f"Sheet2!{cell_name}: value={cell.value}")

print("\n--- SHEET1 BL8:BL10 ---")
for r in range(8, 11):
    val = sheet1.cell(row=r, column=64).value # Column BL is 64
    print(f"BL{r}: {val}")

print("\n--- SHEET1 BM8 ---")
print(f"BM8: {sheet1['BM8'].value}")

print("\n--- SHEET1 BS9:BS30 ---")
for r in range(9, 31):
    val = sheet1.cell(row=r, column=71).value # Column BS is 71
    print(f"BS{r}: {val}")

wb.close()
