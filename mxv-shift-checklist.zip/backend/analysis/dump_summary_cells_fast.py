import openpyxl
import sys

sys.stdout.reconfigure(encoding='utf-8')

wb = openpyxl.load_workbook(r"C:\Users\hiepth\OneDrive - MERCANTILE EXCHANGE OF VIETNAM\Documents\Github\mxv-shift-checklist\marco\Thong ke so lot giao dich có ACM\Macro thong ke so lot giao dich có ACM.xlsm", read_only=True)
sheet1 = wb["Sheet1"]

cells = ["AB71", "AD9", "AB59", "AB60", "AB61", "AB33", "AC52", "AD10", "AD13", "AD11", "BM8", "BS9", "BS75"]

print("Cell | Formula")
for c in cells:
    # To get cell value in read-only mode, we can use cell() method or bracket
    val = sheet1[c].value
    print(f"Sheet1!{c}: {val}")

wb.close()
