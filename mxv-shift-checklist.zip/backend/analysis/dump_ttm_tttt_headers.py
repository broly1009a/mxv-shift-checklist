import openpyxl
import os
import sys

sys.stdout.reconfigure(encoding='utf-8')

base_dir = r"C:\Users\hiepth\Downloads\Quanlygiaodich\Tai lieu hoat dong\Backup MS\Futures\2026\T07.2026\08.07"

for filename in ["TTM.xlsx", "TTTT.xlsx"]:
    path = os.path.join(base_dir, filename)
    if os.path.exists(path):
        wb = openpyxl.load_workbook(path, read_only=True)
        sheet = wb.active
        headers = [sheet.cell(1, c).value for c in range(1, 20)]
        print(f"\n{filename} Headers:")
        for idx, h in enumerate(headers, 1):
            print(f"Col {idx} ({openpyxl.utils.get_column_letter(idx)}): {h}")
        print("First row values:")
        print([sheet.cell(2, c).value for c in range(1, 20)])
        wb.close()
    else:
        print(f"File not found: {path}")
