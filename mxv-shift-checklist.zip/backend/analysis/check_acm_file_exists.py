import os
import sys

sys.stdout.reconfigure(encoding='utf-8')

path = r"C:\Users\hiepth\Downloads\Quanlygiaodich\Tai lieu hoat dong\Thong ke so lot giao dich\Thong ke so lot giao dich ACM 2026.xlsx"
if os.path.exists(path):
    print("ACM file exists locally!")
    print("Size:", os.path.getsize(path))
else:
    print("ACM file does not exist locally")
