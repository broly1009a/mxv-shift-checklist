import openpyxl
import sys

sys.stdout.reconfigure(encoding='utf-8')

wb = openpyxl.load_workbook(r"C:\Users\hiepth\OneDrive - MERCANTILE EXCHANGE OF VIETNAM\Documents\Github\mxv-shift-checklist\marco\Thong ke so lot giao dich có ACM\Macro thong ke so lot giao dich có ACM.xlsm", read_only=True)
sheet = wb["Sheet1"]
print("Row | Z | AA | AB | AC | AD | AE")
for r in range(9, 25):
    z = sheet.cell(row=r, column=26).value # Z
    aa = sheet.cell(row=r, column=27).value # AA
    ab = sheet.cell(row=r, column=28).value # AB
    ac = sheet.cell(row=r, column=29).value # AC
    ad = sheet.cell(row=r, column=30).value # AD
    ae = sheet.cell(row=r, column=31).value # AE
    print(f"{r} | {repr(z)} | {repr(aa)} | {repr(ab)} | {repr(ac)} | {repr(ad)} | {repr(ae)}")
wb.close()
