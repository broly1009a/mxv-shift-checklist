import win32com.client
excel = win32com.client.Dispatch("Excel.Application")
excel.Visible = False
try:
    wb = excel.Workbooks.Open(r"C:\POC\Macro_vba.xlsm", 0, True)
    for c in wb.VBProject.VBComponents:
        if c.CodeModule.CountOfLines > 0:
            code = c.CodeModule.Lines(1, c.CodeModule.CountOfLines)
            for idx, line in enumerate(code.split("\n")):
                if "spread" in line.lower():
                    print(f"Module {c.Name} Line {idx+1}: {line.strip()}")
    wb.Close(False)
finally:
    excel.Quit()
