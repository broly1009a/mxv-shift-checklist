import openpyxl
import os
import sys

sys.stdout.reconfigure(encoding='utf-8')

# The target file is in the local folder or macro folder
path = r"c:\Users\hiepth\OneDrive - MERCANTILE EXCHANGE OF VIETNAM\Documents\Github\mxv-shift-checklist\marco\Thong ke so lot giao dich có ACM\Thong ke so lot giao dich 2026.xlsx"
if not os.path.exists(path):
    # Try Downloads path from Sheet2
    path = r"C:\Users\hiepth\Downloads\Quanlygiaodich\Tai lieu hoat dong\Thong ke so lot giao dich\Thong ke so lot giao dich ACM 2026.xlsx"

if os.path.exists(path):
    wb = openpyxl.load_workbook(path, read_only=True)
    print("Sheets in target workbook:", wb.sheetnames)
    sheet = wb[wb.sheetnames[-1]] # Last sheet
    
    # Print headers of row 1 and 2
    row1 = [sheet.cell(1, c).value for c in range(1, 80)]
    row2 = [sheet.cell(2, c).value for c in range(1, 80)]
    
    print("\nRow 1 headers:")
    for idx, val in enumerate(row1, 1):
        if val is not None:
            print(f"Col {idx} ({openpyxl.utils.get_column_letter(idx)}): {val}")
            
    print("\nRow 2 headers:")
    for idx, val in enumerate(row2, 1):
        if val is not None:
            print(f"Col {idx} ({openpyxl.utils.get_column_letter(idx)}): {val}")
            
    # Sample last 5 data rows
    max_row = sheet.max_row
    print(f"\nMax row: {max_row}")
    for r in range(max_row - 5, max_row + 1):
        if r < 1: continue
        print(f"Row {r}: B={sheet.cell(r, 2).value}, C={sheet.cell(r, 3).value}, D={sheet.cell(r, 4).value}, E={sheet.cell(r, 5).value}, I={sheet.cell(r, 9).value}")
        
    wb.close()
else:
    print(f"File not found: {path}")
