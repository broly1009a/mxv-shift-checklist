import sys
sys.stdout.reconfigure(encoding="utf-8")
import win32com.client
excel = win32com.client.Dispatch("Excel.Application")
excel.Visible = False
try:
    wb = excel.Workbooks.Open(r"C:\POC\Macro_vba.xlsm", 0, True)
    for sheet in wb.Sheets:
        print(f"--- Sheet: {sheet.Name} ---")
        for r in range(1, 150):
            for c in range(1, 15):
                val = sheet.Cells(r, c).Value
                form = sheet.Cells(r, c).Formula
                if val and isinstance(val, str) and ("M:\\" in val or "spread" in val.lower()):
                    print(f"Row {r}, Col {c} Value: {repr(val)}")
                if form and isinstance(form, str) and ("M:\\" in form or "spread" in form.lower()):
                    print(f"Row {r}, Col {c} Formula: {repr(form)}")
    wb.Close(False)
finally:
    excel.Quit()
