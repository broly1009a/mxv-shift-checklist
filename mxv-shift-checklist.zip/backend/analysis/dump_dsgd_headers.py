import openpyxl
import os
import sys

sys.stdout.reconfigure(encoding='utf-8')

path = r"C:\Users\hiepth\Downloads\Quanlygiaodich\Tai lieu hoat dong\Backup MS\Futures\2026\T07.2026\08.07\DSGD.xlsx"
if os.path.exists(path):
    wb = openpyxl.load_workbook(path, read_only=True)
    sheet = wb.active
    
    # Print headers
    headers = [sheet.cell(1, c).value for c in range(1, 25)]
    print("DSGD Headers:")
    for idx, h in enumerate(headers, 1):
        print(f"Col {idx} ({openpyxl.utils.get_column_letter(idx)}): {h}")
        
    print("\nFirst 3 rows:")
    for r in range(2, 5):
        row_vals = [sheet.cell(r, c).value for c in range(1, 20)]
        print(f"Row {r}: {row_vals}")
        
    wb.close()
else:
    print(f"File not found: {path}")
