import openpyxl
import os
import sys

sys.stdout.reconfigure(encoding='utf-8')

path = r"C:\Users\hiepth\Downloads\Quanlygiaodich\Tai lieu hoat dong\Thong ke so lot giao dich\Thong ke so lot giao dich 2026.xlsx"
if os.path.exists(path):
    wb = openpyxl.load_workbook(path, data_only=True)
    sheet = wb["T07.2026"]
    print("Loaded workbook!")
    
    # Let's check some headers in Row 2 and 3
    print("Row 2 (1 to 20):")
    print([sheet.cell(2, c).value for c in range(1, 20)])
    print("Row 3 (1 to 20):")
    print([sheet.cell(3, c).value for c in range(1, 20)])
    
    # Check date column B (row 4 to 20)
    for r in range(4, 20):
        print(f"Row {r} B: {sheet.cell(r, 2).value}")
        
    wb.close()
else:
    print("File not found")
