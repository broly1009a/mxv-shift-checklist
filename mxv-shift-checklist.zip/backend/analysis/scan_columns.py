import openpyxl
import sys

sys.stdout.reconfigure(encoding='utf-8')

wb = openpyxl.load_workbook(r"C:\Users\hiepth\OneDrive - MERCANTILE EXCHANGE OF VIETNAM\Documents\Github\mxv-shift-checklist\marco\Thong ke so lot giao dich có ACM\Macro thong ke so lot giao dich có ACM.xlsm", read_only=True)
sheet = wb["Sheet1"]

cols = ["P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z", "AA", "AB", "AC", "AD", "AE", "AF", "AG", "AH", "AI", "AJ", "AK", "AL", "AM", "AN", "AO", "AS", "AT", "AU", "BL", "BM", "BS"]
col_indices = [openpyxl.utils.column_index_from_string(c) for c in cols]
max_col = max(col_indices)

print("Row, " + ", ".join(cols))
for r_idx, row in enumerate(sheet.iter_rows(min_row=8, max_row=80, max_col=max_col)):
    vals = []
    # Map index to cell value
    for c_idx in col_indices:
        cell_val = row[c_idx - 1].value
        vals.append(str(cell_val) if cell_val is not None else "")
    print(f"Row {r_idx + 8}: " + " | ".join(vals))
wb.close()
