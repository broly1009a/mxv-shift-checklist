import openpyxl
import sys

sys.stdout.reconfigure(encoding='utf-8')

wb = openpyxl.load_workbook(r"C:\Users\hiepth\OneDrive - MERCANTILE EXCHANGE OF VIETNAM\Documents\Github\mxv-shift-checklist\marco\Thong ke so lot giao dich có ACM\Macro thong ke so lot giao dich có ACM.xlsm", read_only=True, data_only=True)
sheet1 = wb["Sheet1"]

print("Row | BP | BQ | BR | BS | BJ | BK | BL")
for r in range(8, 41):
    bp = sheet1.cell(row=r, column=68).value # BP (68)
    bq = sheet1.cell(row=r, column=69).value # BQ (69)
    br = sheet1.cell(row=r, column=70).value # BR (70)
    bs = sheet1.cell(row=r, column=71).value # BS (71)
    bj = sheet1.cell(row=r, column=62).value # BJ (62)
    bk = sheet1.cell(row=r, column=63).value # BK (63)
    bl = sheet1.cell(row=r, column=64).value # BL (64)
    print(f"{r:02d} | {repr(bp)} | {repr(bq)} | {repr(br)} | {repr(bs)} | {repr(bj)} | {repr(bk)} | {repr(bl)}")

wb.close()
