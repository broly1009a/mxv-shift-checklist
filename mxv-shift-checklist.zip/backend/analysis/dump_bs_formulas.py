import openpyxl
import sys

sys.stdout.reconfigure(encoding='utf-8')

wb = openpyxl.load_workbook(r"C:\Users\hiepth\OneDrive - MERCANTILE EXCHANGE OF VIETNAM\Documents\Github\mxv-shift-checklist\marco\Thong ke so lot giao dich có ACM\Macro thong ke so lot giao dich có ACM.xlsm", read_only=True)
sheet1 = wb["Sheet1"]

print("Row | BP | BR | BS")
for r in range(9, 76):
    bp = sheet1.cell(row=r, column=68).value # BP
    br = sheet1.cell(row=r, column=70).value # BR
    bs = sheet1.cell(row=r, column=71).value # BS
    print(f"{r:02d} | {repr(bp)} | {repr(br)} | {repr(bs)}")

wb.close()
