import openpyxl, sys
sys.stdout.reconfigure(encoding='utf-8')
path = r"c:\Users\hiepth\OneDrive - MERCANTILE EXCHANGE OF VIETNAM\Documents\Github\mxv-shift-checklist\marco\Thong ke so lot giao dich có ACM\Macro thong ke so lot giao dich có ACM.xlsm"
wb = openpyxl.load_workbook(path, read_only=True)
s1 = wb['Sheet1']
s2 = wb['Sheet2']
print('Sheet1!N3:', s1['N3'].value)
print('Sheet2!A1:', s2['A1'].value)
print('Sheet2!A12:', s2['A12'].value)
wb.close()
