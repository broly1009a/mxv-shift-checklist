import openpyxl
wb = openpyxl.load_workbook(r"C:\Users\hiepth\OneDrive - MERCANTILE EXCHANGE OF VIETNAM\Documents\Github\mxv-shift-checklist\marco\Thong ke so lot giao dich có ACM\Macro thong ke so lot giao dich có ACM.xlsm", read_only=True)
if "Sheet3" in wb.sheetnames:
    print("Sheet3!A22 Formula:", wb["Sheet3"]["A22"].value)
else:
    print("Sheet3 not found.")
wb.close()
