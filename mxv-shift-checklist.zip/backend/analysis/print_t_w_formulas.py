import openpyxl
wb = openpyxl.load_workbook(r"C:\Users\hiepth\OneDrive - MERCANTILE EXCHANGE OF VIETNAM\Documents\Github\mxv-shift-checklist\marco\Thong ke so lot giao dich có ACM\Macro thong ke so lot giao dich có ACM.xlsm", read_only=True)
sheet = wb["Sheet1"]
print("Row | Q (TVKD) | T Formula | W Formula")
for r in range(9, 75):
    q_val = sheet.cell(row=r, column=17).value # Q
    t_val = sheet.cell(row=r, column=20).value # T
    w_val = sheet.cell(row=r, column=23).value # W
    print(f"{r} | {q_val} | {t_val} | {w_val}")
wb.close()
