import openpyxl
import os
import sys

sys.stdout.reconfigure(encoding='utf-8')

path = r"C:\Users\hiepth\Downloads\Quanlygiaodich\Tai lieu hoat dong\Backup CQG\Futures\2026\T07.2026\08.07\FR.xlsx"
if os.path.exists(path):
    wb = openpyxl.load_workbook(path, read_only=True)
    sheet = wb.active
    # Read first 10 rows of B column
    for r in range(2, 12):
        val = sheet.cell(r, 2).value
        print(f"Row {r}: Value={repr(val)}, Type={type(val)}")
    wb.close()
else:
    print(f"File not found: {path}")
