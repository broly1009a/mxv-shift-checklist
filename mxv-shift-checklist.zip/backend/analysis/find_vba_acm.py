import sys

sys.stdout.reconfigure(encoding='utf-8')

file_path = r"c:\Users\hiepth\OneDrive - MERCANTILE EXCHANGE OF VIETNAM\Documents\Github\mxv-shift-checklist\artifacts\acm_vba_extracted_code.txt"

with open(file_path, "r", encoding="utf-8") as f:
    lines = f.readlines()

for i, line in enumerate(lines, 1):
    if "ACM" in line or "TTM" in line or "TTTT" in line:
        print(f"Line {i}: {line.strip()}")
