import openpyxl
import os
import sys

sys.stdout.reconfigure(encoding='utf-8')

path = r"C:\Users\hiepth\Downloads\Quanlygiaodich\Tai lieu hoat dong\Backup MS\Futures\2026\T07.2026\08.07\DSGD.xlsx"
if os.path.exists(path):
    wb = openpyxl.load_workbook(path, read_only=True)
    sheet = wb.active
    # Find rows with "-A" in Column D (Mã TKGD)
    acm_rows = []
    for r in range(2, sheet.max_row + 1):
        tkgd = sheet.cell(r, 4).value
        if tkgd and "-A" in str(tkgd):
            row_data = {
                "Row": r,
                "TKGD (D)": tkgd,
                "Symbol (F)": sheet.cell(r, 6).value,
                "Qty (M)": sheet.cell(r, 13).value,
                "ColQ (Q)": sheet.cell(r, 17).value
            }
            acm_rows.append(row_data)
            if len(acm_rows) >= 5:
                break
    wb.close()
    print("Sample ACM Rows:")
    for row in acm_rows:
        print(row)
else:
    print(f"File not found: {path}")
