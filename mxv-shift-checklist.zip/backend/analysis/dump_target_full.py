import openpyxl
import os
import sys

sys.stdout.reconfigure(encoding='utf-8')

path = r"C:\Users\hiepth\Downloads\Quanlygiaodich\Tai lieu hoat dong\Thong ke so lot giao dich\Thong ke so lot giao dich ACM 2026.xlsx"

if os.path.exists(path):
    wb = openpyxl.load_workbook(path, read_only=True)
    sheet = wb["T07.2026"]
    
    print("Row | Col A | Col B | Col C | Col D | Col E | Col I | Col K | Col L | Col M | Col BT | Col BU")
    for r in range(1, 100):
        b = sheet.cell(r, 2).value
        # If row is empty, skip
        if not b:
            # check if there's any other value
            any_val = any(sheet.cell(r, c).value for c in range(1, 100))
            if not any_val:
                continue
        a = sheet.cell(r, 1).value
        c = sheet.cell(r, 3).value
        d = sheet.cell(r, 4).value
        e = sheet.cell(r, 5).value
        i = sheet.cell(r, 9).value
        k = sheet.cell(r, 11).value
        l = sheet.cell(r, 12).value
        m = sheet.cell(r, 13).value
        bt = sheet.cell(r, 72).value # BT is 72
        bu = sheet.cell(r, 73).value # BU is 73
        print(f"{r:02d} | {a} | {b} | {c} | {d} | {e} | {i} | {k} | {l} | {m} | {bt} | {bu}")
        
    wb.close()
else:
    print(f"File not found: {path}")
