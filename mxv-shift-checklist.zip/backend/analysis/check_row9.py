import openpyxl
wb = openpyxl.load_workbook(r"C:\Users\hiepth\OneDrive - MERCANTILE EXCHANGE OF VIETNAM\Documents\Github\mxv-shift-checklist\marco\Thong ke so lot giao dich có ACM\Macro thong ke so lot giao dich có ACM.xlsm", read_only=True)
sheet = wb["Sheet1"]
cols = ["P", "Q", "R", "S", "T", "U", "V", "W", "X"]
for c in cols:
    print(f"{c}9: {sheet[c+'9'].value}")
wb.close()
