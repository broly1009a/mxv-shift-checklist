import openpyxl
import os
import sys

sys.stdout.reconfigure(encoding='utf-8')

path = r"C:\Users\hiepth\Downloads\Quanlygiaodich\Tai lieu hoat dong\Backup MS\Futures\2026\T07.2026\08.07\TTTT.xlsx"
if os.path.exists(path):
    wb = openpyxl.load_workbook(path, read_only=True)
    sheet = wb.active
    
    print("Row | TKGD (H) | HD (J) | KL Mua (P) | KL Ban (Q)")
    count = 0
    for r in range(2, sheet.max_row + 1):
        tkgd = sheet.cell(r, 8).value
        if tkgd and "-A" in str(tkgd):
            hd = sheet.cell(r, 10).value
            kl_mua = sheet.cell(r, 16).value
            kl_ban = sheet.cell(r, 17).value
            print(f"{r} | {tkgd} | {hd} | {kl_mua} | {kl_ban}")
            count += 1
            if count >= 10:
                break
    wb.close()
else:
    print(f"File not found: {path}")
