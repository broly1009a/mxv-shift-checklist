import sys
sys.stdout.reconfigure(encoding="utf-8")
import win32com.client
excel = win32com.client.Dispatch("Excel.Application")
excel.Visible = False
try:
    wb = excel.Workbooks.Open(r"C:\POC\Macro_vba.xlsm", 0, True)
    with open("vba_code.txt", "w", encoding="utf-8") as f:
        for c in wb.VBProject.VBComponents:
            if c.CodeModule.CountOfLines > 0:
                f.write(f"\n\n' ======================================\n")
                f.write(f"' MODULE: {c.Name}\n")
                f.write(f"' ======================================\n")
                code = c.CodeModule.Lines(1, c.CodeModule.CountOfLines)
                f.write(code)
    print("Exported successfully to vba_code.txt")
    wb.Close(False)
finally:
    excel.Quit()
