import openpyxl
import sys

sys.stdout.reconfigure(encoding='utf-8')

wb = openpyxl.load_workbook(r"C:\Users\hiepth\OneDrive - MERCANTILE EXCHANGE OF VIETNAM\Documents\Github\mxv-shift-checklist\marco\Thong ke so lot giao dich có ACM\Macro thong ke so lot giao dich có ACM.xlsm", read_only=True)
sheet1 = wb["Sheet1"]

print("Row | B | C | D | E")
for r in range(1, 40):
    b = sheet1.cell(row=r, column=2).value
    c = sheet1.cell(row=r, column=3).value
    d = sheet1.cell(row=r, column=4).value
    e = sheet1.cell(row=r, column=5).value
    if b is None and c is None and d is None and e is None:
        continue
    print(f"{r:02d} | {repr(b)} | {repr(c)} | {repr(d)} | {repr(e)}")

wb.close()
