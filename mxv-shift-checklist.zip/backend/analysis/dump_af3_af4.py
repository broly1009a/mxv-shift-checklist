import openpyxl
import sys

sys.stdout.reconfigure(encoding='utf-8')

wb = openpyxl.load_workbook(r"C:\Users\hiepth\OneDrive - MERCANTILE EXCHANGE OF VIETNAM\Documents\Github\mxv-shift-checklist\marco\Thong ke so lot giao dich có ACM\Macro thong ke so lot giao dich có ACM.xlsm", read_only=True)

for sheet_name in ["Sheet1", "Sheet2"]:
    sheet = wb[sheet_name]
    print(f"\n--- {sheet_name} ---")
    for cell in ["AF3", "AF4"]:
        print(f"{cell} formula: {sheet[cell].value}")

wb.close()
