import openpyxl
import sys

sys.stdout.reconfigure(encoding='utf-8')

wb = openpyxl.load_workbook(r"C:\Users\hiepth\OneDrive - MERCANTILE EXCHANGE OF VIETNAM\Documents\Github\mxv-shift-checklist\marco\Thong ke so lot giao dich có ACM\Macro thong ke so lot giao dich có ACM.xlsm", read_only=True)
sheet = wb["Sheet1"]

print("Scanning Sheet1...")
for r_idx, row in enumerate(sheet.iter_rows(max_row=100, max_col=100)):
    row_vals = []
    has_formula_or_val = False
    for c_idx, cell in enumerate(row):
        val = cell.value
        if val is not None:
            has_formula_or_val = True
            cell_ref = openpyxl.utils.get_column_letter(c_idx + 1) + str(r_idx + 1)
            row_vals.append(f"{cell_ref}: {repr(val)}")
    if has_formula_or_val:
        print(f"Row {r_idx + 1}: " + ", ".join(row_vals[:15]))
wb.close()
