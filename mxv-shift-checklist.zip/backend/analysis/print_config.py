import openpyxl
import datetime

wb = openpyxl.load_workbook(r"C:\Users\hiepth\OneDrive - MERCANTILE EXCHANGE OF VIETNAM\Documents\Github\mxv-shift-checklist\marco\Thong ke so lot giao dich có ACM\Macro thong ke so lot giao dich có ACM.xlsm", read_only=True, data_only=True)
sheet2 = wb["Sheet2"]
sheet1 = wb["Sheet1"]

cells = ["A15", "A28", "A32", "A34", "A18", "X2", "X4", "Y1", "A21", "A77"]
for c in cells:
    val = sheet2[c].value
    print(f"Sheet2!{c}: Value={repr(val)}, Type={type(val)}")

print(f"Sheet1!N3: Value={repr(sheet1['N3'].value)}, Type={type(sheet1['N3'].value)}")
wb.close()
