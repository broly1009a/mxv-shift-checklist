import openpyxl
wb = openpyxl.load_workbook(r"C:\Users\hiepth\OneDrive - MERCANTILE EXCHANGE OF VIETNAM\Documents\Github\mxv-shift-checklist\marco\Thong ke so lot giao dich có ACM\Macro thong ke so lot giao dich có ACM.xlsm", read_only=True)
sheet2 = wb["Sheet2"]
for r in [1, 2, 3, 4, 12]:
    print(f"Row {r} Formula: {sheet2.cell(row=r, column=1).value}")
wb.close()
