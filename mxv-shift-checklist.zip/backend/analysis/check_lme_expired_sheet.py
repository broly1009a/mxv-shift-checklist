import openpyxl
wb = openpyxl.load_workbook(r"C:\Users\hiepth\OneDrive - MERCANTILE EXCHANGE OF VIETNAM\Documents\Github\mxv-shift-checklist\marco\Thong ke so lot giao dich có ACM\Macro thong ke so lot giao dich có ACM.xlsm", data_only=True)
print("Sheets:", wb.sheetnames)
if "LME Expired" in wb.sheetnames:
    sheet = wb["LME Expired"]
    print("LME Expired row 1 to 5 values:")
    for r in range(1, min(6, sheet.max_row + 1)):
        row_vals = [sheet.cell(r, c).value for c in range(1, min(20, sheet.max_column + 1))]
        print(f"Row {r}: {row_vals}")
wb.close()
