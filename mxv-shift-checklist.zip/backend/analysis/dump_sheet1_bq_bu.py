import openpyxl
import sys

sys.stdout.reconfigure(encoding='utf-8')

wb = openpyxl.load_workbook(r"C:\Users\hiepth\OneDrive - MERCANTILE EXCHANGE OF VIETNAM\Documents\Github\mxv-shift-checklist\marco\Thong ke so lot giao dich có ACM\Macro thong ke so lot giao dich có ACM.xlsm", read_only=True)
sheet1 = wb["Sheet1"]

print("Row | BQ | BR | BS | BT | BU")
for r in range(8, 41):
    bq = sheet1.cell(row=r, column=69).value # BQ (69)
    br = sheet1.cell(row=r, column=70).value # BR (70)
    bs = sheet1.cell(row=r, column=71).value # BS (71)
    bt = sheet1.cell(row=r, column=72).value # BT (72)
    bu = sheet1.cell(row=r, column=73).value # BU (73)
    print(f"{r:02d} | {repr(bq)} | {repr(br)} | {repr(bs)} | {repr(bt)} | {repr(bu)}")

wb.close()
