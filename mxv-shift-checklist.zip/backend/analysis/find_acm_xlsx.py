import os
import sys

sys.stdout.reconfigure(encoding='utf-8')

search_dirs = [
    r"c:\Users\hiepth\OneDrive - MERCANTILE EXCHANGE OF VIETNAM\Documents\Github\mxv-shift-checklist",
    r"C:\Users\hiepth\Downloads\Quanlygiaodich",
    r"C:\POC"
]

print("Searching for files containing 'ACM' and '.xlsx' or '.xlsm':")
for sdir in search_dirs:
    if not os.path.exists(sdir):
        continue
    for root, dirs, files in os.walk(sdir):
        for f in files:
            if "acm" in f.lower() and (f.endswith(".xlsx") or f.endswith(".xlsm")):
                full_path = os.path.join(root, f)
                print(f"Found: {full_path}")
