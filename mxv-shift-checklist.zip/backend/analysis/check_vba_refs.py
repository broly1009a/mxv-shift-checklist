import win32com.client
excel = win32com.client.Dispatch('Excel.Application')
excel.Visible = False
wb = excel.Workbooks.Open(r'C:\POC\Macro_vba.xlsm', 0, True)
try:
    for c in wb.VBProject.VBComponents:
        if c.CodeModule.CountOfLines > 0:
            code = c.CodeModule.Lines(1, c.CodeModule.CountOfLines)
            for r in [22, 41, 82]:
                if f'A{r}' in code or f'Range("A{r}")' in code or f'Cells({r}' in code:
                    print(f'{c.Name} references Row {r}!')
except Exception as e:
    print('Error:', e)
wb.Close(False)
excel.Quit()
