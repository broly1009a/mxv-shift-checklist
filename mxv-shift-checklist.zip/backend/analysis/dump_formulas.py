import openpyxl
import sys

sys.stdout.reconfigure(encoding='utf-8')

wb = openpyxl.load_workbook(r"C:\Users\hiepth\OneDrive - MERCANTILE EXCHANGE OF VIETNAM\Documents\Github\mxv-shift-checklist\marco\Thong ke so lot giao dich có ACM\Macro thong ke so lot giao dich có ACM.xlsm", read_only=True)
sheet = wb["Sheet1"]
print("Row | P | Q | R | S | T | U | V | W")
for r in range(9, 69):
    p = sheet.cell(row=r, column=16).value
    q = sheet.cell(row=r, column=17).value
    r_val = sheet.cell(row=r, column=18).value
    s = sheet.cell(row=r, column=19).value
    t = sheet.cell(row=r, column=20).value
    u = sheet.cell(row=r, column=21).value
    v = sheet.cell(row=r, column=22).value
    w = sheet.cell(row=r, column=23).value
    print(f"{r} | {repr(p)} | {repr(q)} | {repr(r_val)} | {repr(s)} | {repr(t)} | {repr(u)} | {repr(v)} | {repr(w)}")
wb.close()
