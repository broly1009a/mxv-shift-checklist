import openpyxl
import sys

sys.stdout.reconfigure(encoding='utf-8')

wb = openpyxl.load_workbook(r"C:\Users\hiepth\OneDrive - MERCANTILE EXCHANGE OF VIETNAM\Documents\Github\mxv-shift-checklist\marco\Thong ke so lot giao dich có ACM\Macro thong ke so lot giao dich có ACM.xlsm", read_only=True)
sheet1 = wb["Sheet1"]

print("Row | AX | AY | AZ | BA | BJ | BK | BL | BR | BS")
for r in range(8, 41):
    ax = sheet1.cell(row=r, column=50).value # AX (50)
    ay = sheet1.cell(row=r, column=51).value # AY (51)
    az = sheet1.cell(row=r, column=52).value # AZ (52)
    ba = sheet1.cell(row=r, column=53).value # BA (53)
    bj = sheet1.cell(row=r, column=62).value # BJ (62)
    bk = sheet1.cell(row=r, column=63).value # BK (63)
    bl = sheet1.cell(row=r, column=64).value # BL (64)
    br = sheet1.cell(row=r, column=70).value # BR (70)
    bs = sheet1.cell(row=r, column=71).value # BS (71)
    print(f"{r:02d} | {repr(ax)} | {repr(ay)} | {repr(az)} | {repr(ba)} | {repr(bj)} | {repr(bk)} | {repr(bl)} | {repr(br)} | {repr(bs)}")

print("\n--- Columns BJ, BK, BL at row 8, 9, 10 ---")
for r in [8, 9, 10]:
    bj = sheet1.cell(row=r, column=62).value
    bk = sheet1.cell(row=r, column=63).value
    bl = sheet1.cell(row=r, column=64).value
    print(f"Row {r} | BJ: {repr(bj)} | BK: {repr(bk)} | BL: {repr(bl)}")

wb.close()
