import os
import sys

sys.stdout.reconfigure(encoding='utf-8')

search_dirs = [
    r"c:\Users\hiepth\OneDrive - MERCANTILE EXCHANGE OF VIETNAM\Documents\Github\mxv-shift-checklist",
    r"C:\Users\hiepth\Downloads\Quanlygiaodich",
    r"C:\POC"
]

print("Searching for .xlsx or .xlsm files:")
for sdir in search_dirs:
    if not os.path.exists(sdir):
        print(f"Directory does not exist: {sdir}")
        continue
    print(f"\n--- {sdir} ---")
    for root, dirs, files in os.walk(sdir):
        for f in files:
            if f.endswith(".xlsx") or f.endswith(".xlsm"):
                full_path = os.path.join(root, f)
                print(f"Found: {full_path} (Size: {os.path.getsize(full_path)} bytes)")
