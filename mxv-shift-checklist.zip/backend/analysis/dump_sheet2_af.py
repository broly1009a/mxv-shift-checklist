import openpyxl
import sys

sys.stdout.reconfigure(encoding='utf-8')

wb = openpyxl.load_workbook(r"C:\Users\hiepth\OneDrive - MERCANTILE EXCHANGE OF VIETNAM\Documents\Github\mxv-shift-checklist\marco\Thong ke so lot giao dich có ACM\Macro thong ke so lot giao dich có ACM.xlsm", read_only=True)
sheet2 = wb["Sheet2"]

print("Row | Col AF (32)")
for r in range(1, 15):
    print(f"Row {r}: {sheet2.cell(row=r, column=32).value}") # 32 is AF

wb.close()
