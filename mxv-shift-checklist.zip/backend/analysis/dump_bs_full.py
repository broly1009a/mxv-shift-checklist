import openpyxl
import sys

sys.stdout.reconfigure(encoding='utf-8')

wb = openpyxl.load_workbook(r"C:\Users\hiepth\OneDrive - MERCANTILE EXCHANGE OF VIETNAM\Documents\Github\mxv-shift-checklist\marco\Thong ke so lot giao dich có ACM\Macro thong ke so lot giao dich có ACM.xlsm", read_only=True, data_only=True)
sheet1 = wb["Sheet1"]

print("Row | BP | BQ | BR | BS")
for r in range(41, 100):
    bp = sheet1.cell(row=r, column=68).value # BP (68)
    bq = sheet1.cell(row=r, column=69).value # BQ (69)
    br = sheet1.cell(row=r, column=70).value # BR (70)
    bs = sheet1.cell(row=r, column=71).value # BS (71)
    if bp is None and bq is None and br is None and bs is None:
        continue
    print(f"{r:02d} | {repr(bp)} | {repr(bq)} | {repr(br)} | {repr(bs)}")

wb.close()
