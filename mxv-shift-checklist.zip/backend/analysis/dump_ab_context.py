import openpyxl
import sys

sys.stdout.reconfigure(encoding='utf-8')

wb = openpyxl.load_workbook(r"C:\Users\hiepth\OneDrive - MERCANTILE EXCHANGE OF VIETNAM\Documents\Github\mxv-shift-checklist\marco\Thong ke so lot giao dich có ACM\Macro thong ke so lot giao dich có ACM.xlsm", read_only=True)
sheet1 = wb["Sheet1"]

print("Row | Z | AA | AB | AC | AD")
for r in range(50, 80):
    z = sheet1.cell(row=r, column=26).value # Z is 26
    aa = sheet1.cell(row=r, column=27).value # AA is 27
    ab = sheet1.cell(row=r, column=28).value # AB is 28
    ac = sheet1.cell(row=r, column=29).value # AC is 29
    ad = sheet1.cell(row=r, column=30).value # AD is 30
    print(f"{r:02d} | {repr(z)} | {repr(aa)} | {repr(ab)} | {repr(ac)} | {repr(ad)}")

wb.close()
