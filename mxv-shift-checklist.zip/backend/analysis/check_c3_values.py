import openpyxl
import sys

sys.stdout.reconfigure(encoding='utf-8')

wb = openpyxl.load_workbook(r"C:\Users\hiepth\OneDrive - MERCANTILE EXCHANGE OF VIETNAM\Documents\Github\mxv-shift-checklist\marco\Thong ke so lot giao dich có ACM\Macro thong ke so lot giao dich có ACM.xlsm", read_only=True, data_only=True)
sheet2 = wb["Sheet2"]
print("C3:", sheet2["C3"].value)
for cell in ["A54", "A55", "A56", "A57", "A58", "A59", "A60"]:
    print(f"{cell}: {sheet2[cell].value}")
wb.close()
