import openpyxl
import os
import sys

sys.stdout.reconfigure(encoding='utf-8')

for name, filename in [("OP", "OP.xlsx"), ("PS", "PS.xlsx")]:
    path = os.path.join(r"C:\Users\hiepth\Downloads\Quanlygiaodich\Tai lieu hoat dong\Backup CQG\Futures\2026\T07.2026\08.07", filename)
    if os.path.exists(path):
        wb = openpyxl.load_workbook(path, read_only=True)
        sheet = wb.active
        headers = [sheet.cell(1, col).value for col in range(1, 20)]
        print(f"\n{name} Headers:")
        for idx, h in enumerate(headers):
            if h is not None:
                print(f"Col {idx+1}: {h}")
        wb.close()
    else:
        print(f"File not found: {path}")
